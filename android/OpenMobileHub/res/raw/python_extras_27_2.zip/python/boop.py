import android
import pp

def goBoop():
	droid = android.Android()
	droid.makeToast("Boop pp!")