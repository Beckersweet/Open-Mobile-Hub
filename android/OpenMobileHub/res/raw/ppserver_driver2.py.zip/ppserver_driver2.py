import android, signal
from ppserver import create_network_server, signal_handler

droid = android.Android()

# Open file with broadcast address.
broadcastAddress = ''
fileName = 'broadcast_address.txt'
with open(fileName, 'r') as addressFile:
	broadcastAddress = addressFile.readline()

# broadcastAddress = droid.dialogGetInput("Parallel Python",
# 		"Please enter the IP address of the jobserver:").result
server = create_network_server(['-d', '-a', '-b', broadcastAddress, '-w', '1'])
if hasattr(signal, 'SIGUSR1'):
	signal.signal(signal.SIGUSR1, signal_handler)
droid.makeToast("Broadcasting to " + broadcastAddress + "...")
server.listen()
del server
